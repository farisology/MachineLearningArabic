# svm
Support Vector Machine from scratch using Python3
